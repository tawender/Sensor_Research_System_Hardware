measurement_board rev.1 layer output file descriptions

filename						description
---------------------------------------------------------------------------
measurement_board-F.SilkS.gto		top silkscreen
measurement_board-F.Paste.gtp		top solderpaste
measurement_board-F.Mask.gts		top soldermask
measurement_board-F.Cu.gtl			top copper
measurement_board-In1.Cu.g2			mid layer 1 copper
measurement_board-In2.Cu.g3			mid layer 2 copper
measurement_board-B.Cu.gbl			bottom copper
measurement_board-B.Mask.gbs		bottom soldermask
measurement_board-B.Paste.gbp		bottom solderpaste
measurement_board-B.SilkS.gbo		bottom silkscreen
measurement_board-Edge.Cuts.gm1		board outline
measurement_board.drl				NC Drill File
measurement_board_rev1_BOM.xls		Bill of Materials
measurement_board-all.pos			pick-and-place